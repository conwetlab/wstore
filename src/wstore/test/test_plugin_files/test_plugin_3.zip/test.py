from wstore.offerings.resource_plugins.plugin import Plugin

class TestPluginInv():
    pass
