from wstore.offerings.resource_plugins.plugin import Plugin

class TestPlugin(Plugin):
    pass
